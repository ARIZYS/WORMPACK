#version 150
/* MakeUp - gbuffers_skybasic.vsh
Render: Sky

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define GBUFFER_SKYBASIC
#define NO_SHADOWS

#include "/common/skybasic_vertex.glsl"
