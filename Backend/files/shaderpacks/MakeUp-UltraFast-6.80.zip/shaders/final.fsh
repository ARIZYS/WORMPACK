#version 150
/* MakeUp - final.fsh
Render: Final renderer

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define FINAL_SHADER
#define NO_SHADOWS

#include "/common/final_fragment.glsl"
