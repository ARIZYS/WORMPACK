#version 150

#moj_import <eg_custom_xp/logic/xp_bar.glsl>
uniform float GameTime;

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = cxp_applyXpBarAnimation(texture(Sampler0, texCoord0), GameTime);
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
